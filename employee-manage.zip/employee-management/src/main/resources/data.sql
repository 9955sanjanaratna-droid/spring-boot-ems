DELETE FROM users;
DELETE FROM employee;

INSERT INTO users (username, password, role) VALUES
('admin', '$2a$10$SisY2gyyHtFo9K262AU.j.gr2OkVQhLyICh4m4sWhMF/mqEDNHUKe', 'ADMIN'),
('user',  '$2a$10$SisY2gyyHtFo9K262AU.j.gr2OkVQhLyICh4m4sWhMF/mqEDNHUKe', 'USER');
INSERT INTO employee (name, email, department) VALUES
('Alice', 'alice@gmail.com', 'HR'),
('Bob', 'bob@gmail.com', 'Finance');

